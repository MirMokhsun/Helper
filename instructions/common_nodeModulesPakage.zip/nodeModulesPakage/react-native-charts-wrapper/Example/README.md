
## How to run Example

cd Example

yarn install 





### android

react-native link

react-native run-android


### ios


cd ios

pod install 

react-native run-ios
